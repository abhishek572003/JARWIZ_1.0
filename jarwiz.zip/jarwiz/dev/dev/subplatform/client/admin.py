from django.contrib import admin

from . models import Subscription

admin.site.register(Subscription)
