from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, get_user_model
from .models import CustomUser
from django import forms

class CreateUserForm(UserCreationForm):

    class Meta:

        model = CustomUser
        fields = ['email','phone', 'first_name', 'last_name', 'password1', 'password2']
    
    def clean(self, *args, **kwargs):
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')
        email_check = CustomUser.objects.filter(email=email)
        if email_check.exists():
            raise forms.ValidationError('This Email already exists')
        return super(CreateUserForm, self).clean(*args, **kwargs)


class LoginForm(forms.Form):
    email = forms.CharField()
    password = forms.CharField()



