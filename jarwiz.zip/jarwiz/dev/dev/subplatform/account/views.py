from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from .token import account_activation_token
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.shortcuts import render, redirect
from .forms import CreateUserForm, LoginForm
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.shortcuts import redirect, render 
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponse

@csrf_protect
def signup_view(request):
    if request.method == "POST":
        form=CreateUserForm(request.POST)
        first_name= request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email', 'default user')
        phone = request.POST.get('phone')
        password1= request.POST.get('password1')
        password2= request.POST.get('password2')
        userHash= email.replace('@','')
       # userHash =~ s/'@'//g

        #new =User.objects.filter(username = userHash)

        if password1 != password2:
            return render(request, 'signup.html',{'error_message': ' Passwords Different'})
        else:
            user = User.objects.create_user((userHash, password1))
            user.save()
            login(request, user)
            current_site = get_current_site(request)
            subject = "Verify Email"
            message = render_to_string('account/verify_email_message.html', {
                'user': user,
                'domain': current_site.domain,
                'uid':urlsafe_base64_encode(force_bytes(user.pk)),
                'token':account_activation_token.make_token(user),
            })
            email = EmailMessage(
                subject, message, to=[email]
            )
            email.send()
            return HttpResponse("Please Confirm your email address to complete the registration") and  render(request,'account/landing.html')
    else:
        form = CreateUserForm()
        context = {
        'form': form
        }
        return render(request, 'account/signup.html', context)


# so we can reference the user model as User instead of CustomUser
User = get_user_model()

# send email with verification link
def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        return HttpResponse("Thank you for this confirmation") and render(request, 'account/index.html')   
    else:
        messages.warning(request, 'The link is invalid.')
    return render(request, 'account/index.html')


def home(request):
    return render(request, 'account/index.html')


def faq(request):
    return render(request, 'account/faq.html')


def about(request):
    return render(request, 'account/about.html')

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)    
                return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'account/my-login.html', {'form': form})
   

def user_logout(request):
    logout(request)
    return redirect('login')

def landing(request):
    return render(request,'account/landing.html')

def profile(request):
    return render(request, 'account/profile.html')


#retry

